1. Run RUN.bat to open up the jar file
2. If an error comes up with "Windows protected your PC" while trying to run the bat file, click "More info" and then "Run anyway"