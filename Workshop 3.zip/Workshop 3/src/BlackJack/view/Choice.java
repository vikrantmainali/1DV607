package BlackJack.view;

public enum Choice 
{
	Play,
	Hit,
	Stand,
	Quit,
	Invalid
}
