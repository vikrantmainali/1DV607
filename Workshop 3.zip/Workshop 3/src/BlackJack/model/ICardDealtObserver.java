package BlackJack.model;

public interface ICardDealtObserver {

		void CardDealt();
}
